#include <zephyr/types.h>
#include <stddef.h>
#include <zephyr/sys/printk.h>
#include <zephyr/kernel.h>
#include <zephyr/bluetooth/bluetooth.h>
#include <zephyr/bluetooth/conn.h>

// Nome do dispositivo
#define DEVICE_NAME "Zephyr_Dongle"
#define DEVICE_NAME_LEN (sizeof(DEVICE_NAME) - 1)

// Dados de anúncio
static const struct bt_data ad[] = {
    BT_DATA_BYTES(BT_DATA_FLAGS, (BT_LE_AD_GENERAL | BT_LE_AD_NO_BREDR)),
    BT_DATA(BT_DATA_NAME_COMPLETE, DEVICE_NAME, DEVICE_NAME_LEN),
};

// Callback de conexão
static void connected(struct bt_conn *conn, uint8_t err)
{
    if (err) {
        printk("Erro ao conectar: %u\n", err);
    } else {
        printk("Conectado ao dispositivo central.\n");
    }
}

// Callback de desconexão
static void disconnected(struct bt_conn *conn, uint8_t reason)
{
    printk("Desconectado (razão: %u)\n", reason);
}

// Estruturas de callback
static struct bt_conn_cb conn_callbacks = {
    .connected = connected,
    .disconnected = disconnected,
};

void main(void)
{
    int err;

    printk("Inicializando BLE Dongle\n");

    // Inicializa o Bluetooth
    err = bt_enable(NULL);
    if (err) {
        printk("Erro ao inicializar Bluetooth: %d\n", err);
        return;
    }

    printk("Bluetooth inicializado\n");

    // Registra os callbacks de conexão
    bt_conn_cb_register(&conn_callbacks);

    // Inicia o anúncio BLE
    err = bt_le_adv_start(BT_LE_ADV_CONN, ad, ARRAY_SIZE(ad), NULL, 0);
    if (err) {
        printk("Erro ao iniciar anúncio: %d\n", err);
        return;
    }

    printk("Anúncio iniciado. Aguardando conexões...\n");
}